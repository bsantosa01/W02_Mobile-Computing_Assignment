//
//  ContentView.swift
//  W02_Mobile Computing_Brant Marvel Santosa
//
//

import SwiftUI

struct Task: Identifiable {
    let id = UUID()
    var title: String
    var isDone: Bool = false
}

struct ContentView: View {
    @State private var newTask = ""
    @State private var tasks: [Task] = []
    
    var body: some View {
        VStack {
            
            Text("To Do List")
                .font(.largeTitle)
                .fontWeight(.bold)
                .padding(.top, 20)
            
            HStack {
                TextField("Add new task...", text: $newTask)
                    .textFieldStyle(RoundedBorderTextFieldStyle())
                
                Button("Add", action: addTask)
                    .padding(.horizontal, 10)
                    .padding(.vertical, 5)
                    .background(Color.blue)
                    .foregroundColor(.white)
                    .cornerRadius(8)
            }
            .padding()
            List {
                ForEach($tasks) { $task in
                    HStack {
                        Button {
                            withAnimation(.easeInOut) {
                                task.isDone.toggle()
                            }
                        } label: {
                            Image(systemName: task.isDone ? "checkmark.circle.fill" : "circle")
                                .foregroundColor(task.isDone ? .green : .gray)
                                .font(.system(size: 22))
                        }
                        Text(task.title)
                            .strikethrough(task.isDone, color: .black)
                            .foregroundColor(task.isDone ? .gray : .primary)
                            .animation(.easeInOut, value: task.isDone)
                    }
                }
                .onDelete(perform: deleteTask)
            }
        }
    }
    
    func addTask() {
        guard !newTask.isEmpty else { return }
        withAnimation(.spring(response: 0.4, dampingFraction: 0.7)) {
            tasks.append(Task(title: newTask))
        }
        newTask = ""
    }
    
    func deleteTask(at offsets: IndexSet) {
        withAnimation(.easeInOut) {
            tasks.remove(atOffsets: offsets)
        }
    }
}

#Preview {
    ContentView()
}

