//
//  W02_Mobile_Computing_Brant_Marvel_SantosaApp.swift
//  W02_Mobile Computing_Brant Marvel Santosa
//
//  Created by Muh. Nur Alif Akbar on 24/09/25.
//

import SwiftUI

@main
struct W02_Mobile_Computing_Brant_Marvel_SantosaApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
